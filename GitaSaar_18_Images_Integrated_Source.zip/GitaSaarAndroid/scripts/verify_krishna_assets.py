#!/usr/bin/env python3
from pathlib import Path
from PIL import Image
path=Path('app/src/main/assets/krishna')
expected=['home_banner.webp','guidance_banner.webp','daily_quote.webp','verse_banner.webp']+[f'chapter_{i:02}.webp' for i in range(1,19)]
for name in expected:
    file=path/name
    assert file.exists(),f'Missing bundled artwork: {name}'
    with Image.open(file) as image:
        assert image.width>=450 and image.height>=450,(name,image.size)
print('PASS: all 18 chapter images and 4 screen images present.')
