package com.gitasaar.reader;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.LruCache;
import android.view.View;
import java.io.IOException;
import java.io.InputStream;

/** Dedicated HD images for each chapter. Every image is bundled in app/src/main/assets/krishna.
 * Old public-domain paintings are fallbacks for builds missing optional artwork files.
 * All generated artworks are included in the complete source ZIP. */
public final class KrishnaVisual extends View {
    private static final int CACHE_KB=16*1024;
    private static final LruCache<String, Bitmap> CACHE = new LruCache<String, Bitmap>(CACHE_KB){
        @Override protected int sizeOf(String key,Bitmap value){return value.getByteCount()/1024;}
    };
    private static final int[] FALLBACK={R.drawable.krishna_chariot,R.drawable.krishna_teaching,R.drawable.krishna_battle};
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG|Paint.DITHER_FLAG);
    private final int panel;
    private final float corner;

    /** panel 0=Home, 1..18=individual chapters, 19=Guidance, 20=Daily, 21=Verse. */
    public KrishnaVisual(Context context,int panel){
        super(context);this.panel=panel;
        corner=context.getResources().getDisplayMetrics().density*15f;
    }
    private String file(){
        if(panel==0)return "home_banner.webp";
        if(panel==19)return "guidance_banner.webp";
        if(panel==20)return "daily_quote.webp";
        if(panel==21)return "verse_banner.webp";
        return String.format(java.util.Locale.US,"chapter_%02d.webp", Math.max(1,Math.min(18,panel)));
    }
    private Bitmap bitmap(){
        String name=file();
        Bitmap existing=CACHE.get(name);
        if(existing!=null&&!existing.isRecycled())return existing;
        try(InputStream stream=getContext().getAssets().open("krishna/"+name)){
            BitmapFactory.Options options=new BitmapFactory.Options();
            options.inPreferredConfig=Bitmap.Config.RGB_565;
            Bitmap decoded=BitmapFactory.decodeStream(stream,null,options);
            if(decoded!=null){CACHE.put(name,decoded);return decoded;}
        }catch(IOException ignored){}
        Bitmap fallback=BitmapFactory.decodeResource(getResources(),FALLBACK[Math.floorMod(panel,FALLBACK.length)]);
        if(fallback!=null)CACHE.put(name,fallback);
        return fallback;
    }
    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        Bitmap b=bitmap();if(b==null||getWidth()<=0||getHeight()<=0)return;
        float targetRatio=getWidth()/(float)getHeight();
        float sourceRatio=b.getWidth()/(float)b.getHeight();
        Rect source;
        if(sourceRatio>targetRatio){
            int width=Math.max(1,Math.round(b.getHeight()*targetRatio));
            int left=(b.getWidth()-width)/2;
            source=new Rect(left,0,left+width,b.getHeight());
        }else{
            int height=Math.max(1,Math.round(b.getWidth()/targetRatio));
            int top=Math.max(0,(b.getHeight()-height)/2);
            source=new Rect(0,top,b.getWidth(),Math.min(b.getHeight(),top+height));
        }
        RectF dest=new RectF(0,0,getWidth(),getHeight());
        Path clip=new Path();clip.addRoundRect(dest,corner,corner,Path.Direction.CW);
        canvas.save();canvas.clipPath(clip);canvas.drawBitmap(b,source,dest,paint);canvas.restore();
    }
}
