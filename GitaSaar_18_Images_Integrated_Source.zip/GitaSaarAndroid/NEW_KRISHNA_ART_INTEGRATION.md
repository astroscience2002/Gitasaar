# Gita Saar | Updated Krishna Art Integration

The project contains **18 different chapter images**, one wide **Home hero banner**, and custom images for guidance, daily verses and reading screens. The 18 images are packaged under `app/src/main/assets/krishna/`, not loaded from third-party sites at runtime.

## Where each image appears

* Home main banner: `home_banner.webp`
* Chapter N card: `chapter_NN.webp` (1 through 18)
* Gallery: 18 two-column thumbnails, each opens the respective chapter
* Verse reading: `verse_banner.webp`
* Daily quote: `daily_quote.webp`
* Gita guidance: `guidance_banner.webp`

## Build

Open this project in Android Studio with JDK 17 / Android SDK 36, sync Gradle and run `assembleDebug`. The project's GitHub Actions workflow can build it once these source files are uploaded.

Note that this new source ZIP is **not an APK**. The environment that produced the ZIP cannot compile it locally because it does not contain the Android SDK. The GitHub branch must receive the new image files before its APK will contain them.

The 700 bundled Sanskrit verses and Hindi/English translations are retained unchanged from the latest GitHub project. Before Play Store release, review translations, add your own AdMob IDs, sign the AAB privately and perform real-device testing.
